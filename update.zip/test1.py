import requests
import zipfile
import os
import sys

# Personal access token or API key for the private repository
access_token = "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"

def get_latest_version_from_repository():
    repository_url = "https://api.github.com/repos/Jeapp/test/releases/latest"
    headers = {"Authorization": "token " + access_token}
    response = requests.get(repository_url, headers=headers)

    if response.status_code == 200:
        latest_version = response.json()["tag_name"]
        return latest_version
    return None

def download_and_apply_update(latest_version):
    # Replace this URL with the URL to your update package
    update_url = "https://github.com/Jeapp/test/releases/latest/download/update.zip"
    headers = {"Authorization": "token " + access_token}
    response = requests.get(update_url, headers=headers)

    if response.status_code == 200:
        with open("update.zip", "wb") as f:
            f.write(response.content)

        with zipfile.ZipFile("update.zip", "r") as zip_ref:
            zip_ref.extractall(".")

        os.remove("update.zip")

        # Restart the updated version
        python = sys.executable
        os.execl(python, python, *sys.argv)
    else:
        print("Error downloading the update.")

def check_for_updates():
    current_version = "0.0.0"  # Current version of your program
    latest_version = get_latest_version_from_repository()

    if latest_version and latest_version != current_version:
        print("A new version ({}) is available!".format(latest_version))
        response = input("Would you like to apply the update? (Yes/No): ")
        if response.lower() == "yes":
            download_and_apply_update(latest_version)
    else:
        print("Your program is up to date.")

def main():
    # Your main program code here
    print("Welcome to your application!")
    check_for_updates()

if __name__ == "__main__":
    main() 